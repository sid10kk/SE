# Disaster-Mangement-Website
The Disaster Management website is a responsive platform developed using HTML, CSS, and JavaScript. It provides critical information related to disaster management. The website incorporates a hamburger menu and sticky navbar for intuitive navigation. It is designed to ensure optimal viewing and functionality across different devices.
Link: https://shivank16saxena.github.io/Disaster-Mangement-Website/
